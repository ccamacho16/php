<?php return array (
  'branch-index' => 'App\\Http\\Livewire\\BranchIndex',
  'category-index' => 'App\\Http\\Livewire\\CategoryIndex',
  'client-index' => 'App\\Http\\Livewire\\ClientIndex',
  'history-index' => 'App\\Http\\Livewire\\HistoryIndex',
  'product-index' => 'App\\Http\\Livewire\\ProductIndex',
  'supplier-index' => 'App\\Http\\Livewire\\SupplierIndex',
);
<?php if (isset($component)) { $__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da = $component; } ?>
<?php $component = App\View\Components\AppLayout::resolve([] + (isset($attributes) ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('app-layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $constructor = (new ReflectionClass(App\View\Components\AppLayout::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
     <?php $__env->slot('header', null, []); ?> 
        <h2 class="font-semibold text-xl text-gray-800 leading-tight">
            
            Create Client
        </h2>
     <?php $__env->endSlot(); ?>

    <div class="py-12">
        <div class="max-w-7xl mx-auto sm:px-6 lg:px-8">
            <div class="bg-white overflow-hidden shadow-sm sm:rounded-lg">
				<div class="p-6 bg-white border-b border-gray-200">
					
					<form action="#" id="form">
						<select name="characters" id="characters"></select>
						<input type="submit" value="Get Data">
					</form>

					<table id="table">
						<thead>
							<th>name</th>
							<th>brand</th>
							<th>code</th>
						</thead>
					</table>
					<form action="#" id="form2" method="POST"> 
					
						<?php echo csrf_field(); ?>
						<label> Name
							<input type="text" name="name" value="abcd">
						</label>
						<br>
						<label> Description
							<input type="text" name="description" value="abcdefgh">
						</label>			
						<br>
						<label> Status
							<input type="text" name="status" value="1">
						</label>			
						<br>
						<input type="submit" value="Send Data">
					</form>
					<div id="mensaje"></div>



					<button id="myButton" class="bg-blue-500 text-white font-bold py-2 px-4 rounded">
						Mi botón
					  </button>
					  
					  <div id="myContextMenu" class="hidden bg-white shadow rounded w-40 absolute">
						<a href="#" class="block px-4 py-2 text-gray-800 hover:bg-gray-200">Opción 1</a>
						<a href="#" class="block px-4 py-2 text-gray-800 hover:bg-gray-200">Opción 2</a>
					  </div>

					<br>
					<br>
				</div>
            </div>
        </div>
    </div>



	<script src="<?php echo e(asset('js/prueba.js')); ?>"></script>
 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da)): ?>
<?php $component = $__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da; ?>
<?php unset($__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da); ?>
<?php endif; ?>
<?php /**PATH C:\xampp\htdocs\sgcc\resources\views/sgcc/client/prueba.blade.php ENDPATH**/ ?>
<?php if (isset($component)) { $__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da = $component; } ?>
<?php $component = App\View\Components\AppLayout::resolve([] + (isset($attributes) ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('app-layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $constructor = (new ReflectionClass(App\View\Components\AppLayout::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
     <?php $__env->slot('header', null, []); ?> 
        <div class="grid grid-cols-2 items-center lg:grid-cols-4">

            <div class="flex col-span-2 justify-start items-center lg:col-span-2 ">
                <form action="<?php echo e(route('locker.clear')); ?>" method="POST" id="formCreateLockers">
                    <?php echo csrf_field(); ?>
                    <button type="button" class="mr-2 p-2 bg-gray-100 rounded-full hover:bg-gray-300 active:bg-gray-400 shadow-md" id="btnCreatelockers" value="">
                        <img class="" src="<?php echo e(url('/ico/outline/squares-plus.svg')); ?>"/>
                    </button>
                </form>                                
                
                <form action="<?php echo e(route('locker.clear')); ?>" method="POST" id="formClearLockers">
                    <?php echo csrf_field(); ?>
                    <button type="button" class="mr-4 p-2 bg-gray-100 rounded-full hover:bg-gray-300 active:bg-gray-400 shadow-md lg:mr-6" id="btnClearLockers" value="">
                        <img class="" src="<?php echo e(url('/ico/outline/trash.svg')); ?>"/>
                    </button>
                </form>

                <div class="flex gap-1 mr-4 lg:mr-6">
                    <div class=" flex items-center justify-center center border border-1 w-12 h-10 border-gray-500 bg-blue-400  rounded-l-2xl font-semibold text-lg shadow-md lg:w-14">
                        <span class="" id="in_use">
                        </span>
                    </div>
                    <div class="flex items-center justify-center border border-1 w-12 h-10 border-gray-500  rounded-r-2xl  font-semibold text-lg text-center shadow-md lg:w-14"><span id="available"></span></div>
                </div>                  

                <div class="flex gap-1">
                    <select name="" id="slcTime" class="h-10 font-semibold  rounded-l-2xl border-gray-500 shadow-md focus:border-indigo-300 focus:ring focus:ring-indigo-200 focus:ring-opacity-50">
                        <option value="60">60</option>
                        <option value="90">90</option>
                        <option value="120">120</option>
                    </select>

                    <button type="button" id="btnTime" class=" px-3 shadow-md rounded-r-2xl border border-gray-600 bg-orange-400  hover:bg-orange-500 active:bg-orange-700  focus:border-orange-700  focus:ring ring-orange-300 " >
                        <img class="" width="20" height="20" src="<?php echo e(url('/ico/outline/clock.svg')); ?>"/>
                    </button>							
                </div>                  
            </div>            

            <div class="col-span-2 order-last mt-2 lg:order-none lg:mt-0">
                <form>   
                    <div class="relative">
                        <div class="absolute inset-y-0 left-0 flex items-center pl-3 pointer-events-none">
                            <img id="" class="w-5 h-5" src="<?php echo e(url('/ico/outline/magnifying-glass.svg')); ?>"/>
                        </div>
                        <?php if (isset($component)) { $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4 = $component; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.text-input','data' => ['id' => 'textSearch','class' => 'block mt-1 w-full p-3 pl-10','type' => 'search','name' => 'namelocker','placeholder' => 'Search...','autofocus' => true]] + (isset($attributes) ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('text-input'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes(['id' => 'textSearch','class' => 'block mt-1 w-full p-3 pl-10','type' => 'search','name' => 'namelocker','placeholder' => 'Search...','autofocus' => true]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4)): ?>
<?php $component = $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4; ?>
<?php unset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4); ?>
<?php endif; ?>
                        <?php if (isset($component)) { $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4 = $component; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.xbutton-accept','data' => ['class' => 'absolute right-2.5 shadow-md bg-green-600 hover:bg-green-700 active:bg-green-900  focus:border-green-900  focus:ring ring-green-300 bottom-2','type' => 'button','id' => 'btnSearch']] + (isset($attributes) ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('xbutton-accept'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes(['class' => 'absolute right-2.5 shadow-md bg-green-600 hover:bg-green-700 active:bg-green-900  focus:border-green-900  focus:ring ring-green-300 bottom-2','type' => 'button','id' => 'btnSearch']); ?>
                            Search
                         <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4)): ?>
<?php $component = $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4; ?>
<?php unset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4); ?>
<?php endif; ?>									
                    </div>
                </form>
            </div>                    

        </div>
     <?php $__env->endSlot(); ?>

    <?php echo $__env->make('components.confirmation', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?> 

    <div class="hidden fixed z-10 inset-0 overflow-y-auto" id="modal-create">
        <div class="fixed inset-0 transition-opacity">
            <div class="absolute inset-0 bg-gray-500 opacity-75"></div>
        </div>
        <div class="flex items-end justify-center min-h-screen pt-4 px-4 pb-20 text-center sm:block sm:p-0">
            <span class="hidden bg-green-400 sm:inline-block sm:align-middle sm:h-screen" >&#8203;</span>
            <div class="inline-block align-bottom bg-white rounded-lg px-4 pt-5 pb-4 text-left overflow-hidden shadow-xl transform transition-all sm:my-8 sm:align-middle sm:max-w-sm sm:w-full sm:p-6">
                <form action="<?php echo e(route('locker.create')); ?>" id="formLockersCreate" method="POST" > 
                                      
                        <?php echo csrf_field(); ?>
                        <div class="my-2 mt-4">
                            <?php if (isset($component)) { $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4 = $component; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.input-label','data' => ['for' => 'numLockers','value' => 'Number of Lockers  Min:1 ; Max:60']] + (isset($attributes) ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('input-label'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes(['for' => 'numLockers','value' => 'Number of Lockers  Min:1 ; Max:60']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4)): ?>
<?php $component = $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4; ?>
<?php unset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4); ?>
<?php endif; ?>
                            <div class="flex ">
                                <div  class="w-full">
                                    <?php if (isset($component)) { $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4 = $component; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.text-input','data' => ['id' => 'numLockers','class' => 'mt-1 w-full h-12 text-2xl text-center','type' => 'number','min' => '1','max' => '60','value' => '30','name' => 'numLockers','autofocus' => true]] + (isset($attributes) ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('text-input'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes(['id' => 'numLockers','class' => 'mt-1 w-full h-12 text-2xl text-center','type' => 'number','min' => '1','max' => '60','value' => '30','name' => 'numLockers','autofocus' => true]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4)): ?>
<?php $component = $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4; ?>
<?php unset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4); ?>
<?php endif; ?> 
                                </div>
                            </div>
                        </div>
                        <div class="grid grid-cols-2 gap-2 mt-5 sm:mt-6">
                            <?php if (isset($component)) { $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4 = $component; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.xbutton-cancel','data' => ['class' => 'h-12 w-full focus:border-green-900 ring-green-300 active:bg-green-900 hover:bg-green-700 bg-green-600','type' => 'button','id' => 'btnCancelCreate']] + (isset($attributes) ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('xbutton-cancel'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes(['class' => 'h-12 w-full focus:border-green-900 ring-green-300 active:bg-green-900 hover:bg-green-700 bg-green-600','type' => 'button','id' => 'btnCancelCreate']); ?>
                                Cancel
                             <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4)): ?>
<?php $component = $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4; ?>
<?php unset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4); ?>
<?php endif; ?>								          
                            <?php if (isset($component)) { $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4 = $component; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.xbutton-accept','data' => ['class' => 'h-12','type' => 'submit','id' => 'btnSaveCreate']] + (isset($attributes) ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('xbutton-accept'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes(['class' => 'h-12','type' => 'submit','id' => 'btnSaveCreate']); ?>
                                Save
                             <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4)): ?>
<?php $component = $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4; ?>
<?php unset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4); ?>
<?php endif; ?>			
                        </div>
                </form>
            </div>
        </div>
    </div> 

    <div class="hidden fixed z-10 inset-0 overflow-y-auto" id="modal-locker">
        <div class="fixed inset-0 transition-opacity">
            <div class="absolute inset-0 bg-gray-500 opacity-75"></div>
        </div>
        <div class="flex items-end justify-center min-h-screen pt-4 px-4 pb-20 text-center sm:block sm:p-0">
            <span class="hidden bg-green-400 sm:inline-block sm:align-middle sm:h-screen" >&#8203;</span>
            <div class="inline-block align-bottom bg-white rounded-lg px-4 pt-5 pb-4 text-left overflow-hidden shadow-xl transform transition-all sm:my-8 sm:align-middle sm:max-w-lg sm:w-full sm:p-6">
                
                    <form action="#" id="formlocker" method="POST" >                    
                        <?php echo csrf_field(); ?>
                        <div class="relative">
                            
                            <div class="flex right-0 absolute z-10">
                                <img id="btnClose" class="hover:bg-gray-100 active:bg-gray-200" class="" src="<?php echo e(url('/ico/outline/x-mark.svg')); ?>"/>
                            </div>
                            <div id="timelocker" class="absolute z-10 top-1/2 left-0 transform -translate-y-1/2 text-sm">
                                <div class=""><span id="accesslocker" ></span></div>
                                <div class=""><span id="uselocker" ></span></div>
                            </div>
                            <div class="text-4xl py-2 text-center font-bold border-b-2 border-gray-200 lg:text-6xl">
                                <span class="" id="idlockertext" name="idlockertext"></span>
                            </div>
                        </div>
                        <input type="hidden" name="idlocker" id="idlocker">
                        <div class="my-2 mt-4">
                            <div>
                                <?php if (isset($component)) { $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4 = $component; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.input-label','data' => ['for' => 'namelocker','value' => 'Name']] + (isset($attributes) ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('input-label'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes(['for' => 'namelocker','value' => 'Name']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4)): ?>
<?php $component = $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4; ?>
<?php unset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4); ?>
<?php endif; ?>
                                <div  class="flex items-center">
                                    <?php if (isset($component)) { $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4 = $component; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.text-input','data' => ['id' => 'namelocker','class' => 'mt-1 w-full ','type' => 'text','name' => 'namelocker','value' => '','autofocus' => true]] + (isset($attributes) ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('text-input'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes(['id' => 'namelocker','class' => 'mt-1 w-full ','type' => 'text','name' => 'namelocker','value' => '','autofocus' => true]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4)): ?>
<?php $component = $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4; ?>
<?php unset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4); ?>
<?php endif; ?>
                                </div>
                            </div>
                        </div>
                        
                        <div class="my-2 mt-4">
                            <div class="col-span-2">
                                <?php if (isset($component)) { $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4 = $component; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.input-label','data' => ['for' => 'descriptionlocker','value' => 'Description']] + (isset($attributes) ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('input-label'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes(['for' => 'descriptionlocker','value' => 'Description']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4)): ?>
<?php $component = $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4; ?>
<?php unset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4); ?>
<?php endif; ?>
                                <?php if (isset($component)) { $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4 = $component; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.xtextarea','data' => ['id' => 'descriptionlocker','class' => 'block mt-1 w-full','rows' => '2','name' => 'descriptionlocker']] + (isset($attributes) ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('xtextarea'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes(['id' => 'descriptionlocker','class' => 'block mt-1 w-full','rows' => '2','name' => 'descriptionlocker']); ?>  
                                     <?php $__env->slot('content', null, []); ?>                                          
                                     <?php $__env->endSlot(); ?>
                                 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4)): ?>
<?php $component = $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4; ?>
<?php unset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4); ?>
<?php endif; ?>
                            </div>
                        </div>

                        <div class="grid grid-cols-2 gap-2 mt-5 sm:mt-6">
                            <div class="flex items-center gap-1">
                                <div class="w-1/3 mx-1 lg:w-1/5">
                                    <button type="button" class="rounded-lg h-12 p-2 border-2 hover:bg-gray-200 active:bg-gray-400 focus:outline-none 
                                    focus:border-gray-500 
                                    focus:ring ring-gray-300" id="btnClear" value="">
                                        <img class="" src="<?php echo e(url('/ico/outline/archive-box.svg')); ?>"/>
                                    </button>
                                </div>
                                <div class="w-2/3 lg:w-4/5">
                                    <?php if (isset($component)) { $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4 = $component; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.xbutton-cancel','data' => ['class' => 'h-12 w-full focus:border-green-900 ring-green-300 active:bg-green-900 hover:bg-green-700 bg-green-600','type' => 'submit','id' => 'btnFree']] + (isset($attributes) ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('xbutton-cancel'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes(['class' => 'h-12 w-full focus:border-green-900 ring-green-300 active:bg-green-900 hover:bg-green-700 bg-green-600','type' => 'submit','id' => 'btnFree']); ?>
                                        Free
                                     <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4)): ?>
<?php $component = $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4; ?>
<?php unset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4); ?>
<?php endif; ?>								          
                                </div>
                            </div>                                
                            <?php if (isset($component)) { $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4 = $component; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.xbutton-accept','data' => ['class' => 'h-12','type' => 'submit','id' => 'btnSave']] + (isset($attributes) ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('xbutton-accept'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes(['class' => 'h-12','type' => 'submit','id' => 'btnSave']); ?>
                                Save
                             <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4)): ?>
<?php $component = $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4; ?>
<?php unset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4); ?>
<?php endif; ?>			
                            
                        </div>
                </form>
            </div>
        </div>
    </div> 


    <div class="lg:py-8">
        <div class="max-w-full mx-auto sm:px-6 lg:px-8">
            <div class="bg-white overflow-hidden shadow-sm sm:rounded-lg">
                <div class="p-6 bg-white border-b border-gray-200">

                    
                    <div class="bg-gray-200 p-2 rounded-lg">
                        <div class="grid grid-cols-2 gap-1 lg:grid-cols-5">
                            <?php $__currentLoopData = $lockers; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $locker): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                
                                    <?php if (isset($component)) { $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4 = $component; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.lockerpanel','data' => []] + (isset($attributes) ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('lockerpanel'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
                                        <?php $__env->slot('id'); ?> <?php echo e($locker->id); ?> <?php $__env->endSlot(); ?>
                                        <?php $__env->slot('number'); ?> <?php echo e($locker->number); ?> <?php $__env->endSlot(); ?>
                                        <?php $__env->slot('name'); ?> <?php echo e($locker->name); ?> <?php $__env->endSlot(); ?>
                                        <?php $__env->slot('time_access'); ?> <?php echo e(Str::substr($locker->time_access, 0, 5)); ?> <?php $__env->endSlot(); ?>
                                        <?php $__env->slot('description'); ?> <?php echo e($locker->description); ?> <?php $__env->endSlot(); ?>
                                     <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4)): ?>
<?php $component = $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4; ?>
<?php unset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4); ?>
<?php endif; ?>                     

                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>


 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da)): ?>
<?php $component = $__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da; ?>
<?php unset($__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da); ?>
<?php endif; ?><?php /**PATH C:\xampp\htdocs\sgcc\resources\views/sgcc/locker/index.blade.php ENDPATH**/ ?>
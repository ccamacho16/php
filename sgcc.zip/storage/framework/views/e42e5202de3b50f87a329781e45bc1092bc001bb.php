

<table <?php echo $attributes->merge(['class' => 'w-full text-sm text-left text-gray-500']); ?>>
    <?php echo e($content); ?>

</table><?php /**PATH C:\xampp\htdocs\sgcc\resources\views/components/xtable.blade.php ENDPATH**/ ?>
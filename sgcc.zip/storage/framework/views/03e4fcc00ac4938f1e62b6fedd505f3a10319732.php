<div class="hidden fixed z-10 inset-0 overflow-y-auto" id="confirm-modal">
    
    <div class="fixed inset-0 transition-opacity">
        <div class="absolute inset-0 bg-gray-500 opacity-75"></div>
    </div>

    
    <div class="flex items-end justify-center min-h-screen pt-4 px-4 pb-20 text-center sm:block sm:p-0">

        
        <span class="hidden bg-green-400 sm:inline-block sm:align-middle sm:h-screen" >&#8203;</span>
    
        <div class="inline-block align-bottom bg-white rounded-lg px-4 pt-5 pb-4 text-left overflow-hidden shadow-xl transform transition-all sm:my-8 sm:align-middle sm:max-w-lg sm:w-full sm:p-6">
            <div class="flex">
                <div class="flex items-center w-1/5">
                    
                    <div class="mx-auto flex items-center justify-center h-12 w-12 ">
                        <!-- Icono de confirmación aquí -->
                        <img src="<?php echo e(url('/ico/outline/exclamation-triangle.svg')); ?>" height="50" width="50"/>
                    </div>
                </div>										
                <div class="text-left">
                    <h3 class="text-lg leading-6 font-bold text-gray-900" id="modal-title">
                    ¿You're sure?
                    </h3>
                    <div class="mt-2">
                    <p class="text-base text-gray-500">
                        Confirm the action for the changes to be executed
                    </p>
                    </div>
                </div>
            </div>
            <div class="flex justify-end mt-5 sm:mt-6">
                <?php if (isset($component)) { $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4 = $component; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.xbutton-cancel','data' => ['type' => 'button','class' => 'ml-3','id' => 'btnCancel']] + (isset($attributes) ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('xbutton-cancel'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes(['type' => 'button','class' => 'ml-3','id' => 'btnCancel']); ?>
                    Cancel
                 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4)): ?>
<?php $component = $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4; ?>
<?php unset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4); ?>
<?php endif; ?>
                <?php if (isset($component)) { $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4 = $component; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.xbutton-accept','data' => ['class' => 'ml-3 focus:border-blue-900 ring-blue-300 active:bg-blue-900 hover:bg-blue-700 bg-blue-600','type' => 'button','id' => 'btnConfirm']] + (isset($attributes) ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('xbutton-accept'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes(['class' => 'ml-3 focus:border-blue-900 ring-blue-300 active:bg-blue-900 hover:bg-blue-700 bg-blue-600','type' => 'button','id' => 'btnConfirm']); ?>
                    Confirm
                 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4)): ?>
<?php $component = $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4; ?>
<?php unset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4); ?>
<?php endif; ?>									                
            </div>
        </div>
    </div>
</div><?php /**PATH C:\xampp\htdocs\sgcc\resources\views/components/confirmation.blade.php ENDPATH**/ ?>
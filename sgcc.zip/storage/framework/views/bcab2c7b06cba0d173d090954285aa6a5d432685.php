
<img id="" src="<?php echo e(url('/ico/logolockers.png')); ?>" <?php echo e($attributes); ?>/>
<?php /**PATH C:\xampp\htdocs\sgcc\resources\views/components/application-logo.blade.php ENDPATH**/ ?>
<div>
    <div class="grid grid-cols-2 gap-1 my-2 mt-2 sm:grid-cols-5">        
        <div class="col-span-2 relative sm:col-span-3">
            <div class="absolute inset-y-0 left-0 flex items-center pl-3 pointer-events-none">
                <img id="" class="w-5 h-5" src="<?php echo e(url('/ico/outline/magnifying-glass.svg')); ?>"/>
            </div>
            <?php if (isset($component)) { $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4 = $component; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.text-input','data' => ['wire:model' => 'search','id' => 'search','class' => 'w-full pl-10','type' => 'text','placeholder' => 'Search..']] + (isset($attributes) ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('text-input'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes(['wire:model' => 'search','id' => 'search','class' => 'w-full pl-10','type' => 'text','placeholder' => 'Search..']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4)): ?>
<?php $component = $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4; ?>
<?php unset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4); ?>
<?php endif; ?> 
        </div>
        <div class="sm:ml-4">
            <?php if (isset($component)) { $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4 = $component; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.text-input','data' => ['wire:model' => 'date','id' => '','class' => 'w-full','type' => 'date','value' => ''.e(date('Y-m-d')).'']] + (isset($attributes) ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('text-input'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes(['wire:model' => 'date','id' => '','class' => 'w-full','type' => 'date','value' => ''.e(date('Y-m-d')).'']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4)): ?>
<?php $component = $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4; ?>
<?php unset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4); ?>
<?php endif; ?> 
        </div>        
        <div class="sm:ml-4">
            <?php if (isset($component)) { $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4 = $component; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.xselect','data' => ['wire:model' => 'pagination','name' => '','id' => '','class' => 'w-full']] + (isset($attributes) ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('xselect'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes(['wire:model' => 'pagination','name' => '','id' => '','class' => 'w-full']); ?>    
                 <?php $__env->slot('content', null, []); ?>  
                    <option value="5">5</option>
                    <option value="10">10</option>
                    <option value="15">15</option>
                    <option value="20">20</option>
                 <?php $__env->endSlot(); ?>
             <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4)): ?>
<?php $component = $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4; ?>
<?php unset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4); ?>
<?php endif; ?>
        </div>
    </div>       
    <div class="overflow-x-auto">
        <?php if (isset($component)) { $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4 = $component; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.xtable','data' => ['class' => '']] + (isset($attributes) ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('xtable'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes(['class' => '']); ?>
             <?php $__env->slot('content', null, []); ?>  
                <thead class="text-xs text-gray-700 uppercase bg-gray-50 ">                            
                    <tr>
                        
                        

                        <th scope="col" class="py-3 px-6 text-center">Locker</th>
                        <th scope="col" class="py-3 px-6 text-center">Name</th>
                        <th scope="col" class="py-3 px-6 text-center">Desription</th>
                        <th scope="col" class="py-3 px-6 text-center">CheckIn</th>
                        <th scope="col" class="py-3 px-6 text-center">CheckOut</th>
                    </tr>
                </thead>
                <tbody id='tbody'>
                    <?php $__currentLoopData = $histories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $history): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr class="bg-white border-b">
                            
                            

                            <td class="py-4 px-6 text-center font-bold bg-gray-50"><?php echo e($history->locker); ?></td>
                            <td class="py-4 px-6 font-bold bg-gray-50"><?php echo e($history->name); ?></td>
                            <td class="py-4 px-6"><?php echo e($history->description); ?></td>
                            <td class="py-4 px-6 text-center"><?php echo e($history->check_in); ?></td>
                            <td class="py-4 px-6 text-center"><?php echo e($history->check_out); ?></td>                            

                        </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        
                </tbody>
                
             <?php $__env->endSlot(); ?>
         <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4)): ?>
<?php $component = $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4; ?>
<?php unset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4); ?>
<?php endif; ?>    
    </div>  

    <div class="mt-4">
        <?php echo e($histories->links()); ?>

    </div>
</div>
<?php /**PATH C:\xampp\htdocs\sgcc\resources\views/livewire/history-index.blade.php ENDPATH**/ ?>